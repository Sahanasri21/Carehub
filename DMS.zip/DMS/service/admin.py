from django.contrib import admin
from service.models import Contact, Donator, Feed
from django.contrib.auth.admin import UserAdmin

class ContactAdmin(admin.ModelAdmin):
    list_display=('username', 'email', 'add')
admin.site.register(Contact, ContactAdmin)

class DonatordetailsAdmin(admin.ModelAdmin):
    list_display=('first_name', 'lastname', 'gender', 'companyname', 'date_of_birth',
        'aadharnumber', 'email', 'phonenumber', 'add', 'donationamount')
admin.site.register(Donator, DonatordetailsAdmin)

class FeedAdmin(admin.ModelAdmin):
    list_display=('name', 'email', 'msg')
admin.site.register(Feed, FeedAdmin) 
# Register your models here.
