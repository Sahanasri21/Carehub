from django.db import models
from django.contrib.auth.models import User

class Contact(models.Model):
    username=models.CharField(max_length=10)
    email=models.CharField(max_length=20)
    add=models.TextField()

class Donator(models.Model):
    first_name = models.CharField(max_length=10)
    lastname = models.CharField(max_length=10)
    companyname = models.CharField(max_length=10)
    gender = models.CharField(max_length=10)
    date_of_birth = models.DateField()
    aadharnumber = models.CharField(max_length=12)
    email = models.EmailField()
    phonenumber = models.CharField(max_length=10)
    add = models.TextField()
    donationamount = models.CharField(max_length=10)
 
 
class Feed(models.Model):
    name=models.CharField(max_length=10)
    email=models.CharField(max_length=20)
    msg=models.TextField()
 
 
 
 
# Create your models here.
