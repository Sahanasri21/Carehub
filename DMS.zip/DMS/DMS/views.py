from django.shortcuts import render, redirect
from django.contrib.auth.models import User
from django.contrib.auth import authenticate, login, logout
from django.http import HttpResponse
from django.contrib.auth.decorators import login_required
from service.models import Donator, Contact, Feed

@login_required
def Homepage(request):
    return render(request,'home.html',{})

def Register(request):
    if request.method == 'POST':
        name = request.POST.get('uname')
        email = request.POST.get('email')
        password = request.POST.get('pass')

        new_user = User.objects.create_user(name, email, password)
        new_user.save()
        return redirect('login')
    return render(request, 'register.html', {})


def Login(request):
    if request.method == 'POST':
        name = request.POST.get('uname')
        password = request.POST.get('pass')

        user = authenticate(request, username=name, password=password)
        if user is not None:
            login(request, user)
            return redirect('home')
        else:
            return HttpResponse('Error, user does not exist')
    return render(request, 'login.html', {})

def logoutuser(request):
    logout(request)
    return redirect('login')

def Aboutus(request):
    return render(request,'Aboutus.html', {})

def review(request):
    return render(request,'review.html', {})

def Services(request):
    return render(request,'Services.html', {})

def Contactus(request):
    if request.method == "POST":
        username = request.POST['username']
        email = request.POST['email']
        messages = request.POST['add']
        ins = Contact(username=username,add=messages, email=email)
        ins.save()
        print("ok")
    return render(request,'Contactus.html', {})

def Donatordetails(request):
    if request.method == "POST":
        first_name = request.POST['first_name']
        lastname = request.POST['lastname']
        companyname = request.POST['companyname']
        gender = request.POST['gender']
        date_of_birth = request.POST['date_of_birth']
        aadharnumber = request.POST['aadharnumber']
        email = request.POST['email']
        phonenumber = request.POST['phonenumber']
        add = request.POST['add']
        donationamount = request.POST['donationamount']
        ins = Donator(first_name=first_name, lastname=lastname, companyname=companyname, 
                      gender=gender, date_of_birth=date_of_birth, aadharnumber=aadharnumber, 
                      email=email, phonenumber=phonenumber, add=add, donationamount=donationamount)
        ins.save()
        print("ok")
    return render(request,'Form.html', {})

def Feedback(request):
    if request.method == "POST":
        name = request.POST['name']
        email = request.POST['email']
        messages = request.POST['msg']
        ins = Feed(name=name,msg=messages, email=email)
        ins.save()
        print("ok")
    return render(request,'Feedback.html', {})

# Load the saved model



